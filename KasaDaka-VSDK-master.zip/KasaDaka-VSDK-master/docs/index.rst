.. KasaDaka-VSDK documentation master file, created by
   sphinx-quickstart on Fri Nov 24 13:46:19 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to KasaDaka-VSDK's documentation!
=========================================

The Voice Service Development Kit allows the development of voice-services for the KasaDaka platform.

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
